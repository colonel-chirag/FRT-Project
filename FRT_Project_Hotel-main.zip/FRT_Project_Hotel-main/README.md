# Grill Kitchen 

Grill Kitchen is Hotel website which presents the services provided by the hotel.

## Microsoft Azure Services used in the project are:

1.Microsoft Azure QnA maker.\
2.Microsoft Azure Static Web App

### Use of QnA maker: 
-QnA Maker is a free, easy-to-use, REST API- and web-based service that trains AI to respond to users' questions in a more natural, conversational way.\
-I have used this azure service to help the customers by providing detail about the hotel, food information,etc.\
-I have created a custom knowledge base containing the answers of questions like "What is special in chat?" ,"What are your services?",etc.\
### GrillBot:
![image](https://user-images.githubusercontent.com/86558178/151703631-ccf549ec-abf0-4639-8387-b986e4121007.png)\
![image](https://user-images.githubusercontent.com/86558178/151703578-7e334655-e652-432e-9219-a062c554ed40.png)
![image](https://user-images.githubusercontent.com/86558178/151703643-e78297a2-8582-4e6d-854e-0c6ba63a522b.png)\


### Use of Static Web App : 
-I have used Azure Static Web App to Deploy my website.
![image](https://user-images.githubusercontent.com/86558178/151703846-a09fde2a-ac0f-4533-a016-c717307b6237.png)
![image](https://user-images.githubusercontent.com/86558178/151703859-fb75ad14-4cd7-4eeb-84f9-8065e2b149bd.png)
![image](https://user-images.githubusercontent.com/86558178/151703870-350388c6-e7eb-49af-bae2-db7fd6ccf9f9.png)

### Grill Kitchen - Website Link:
https://brave-mud-077cb1610.1.azurestaticapps.net


## Thank You.
